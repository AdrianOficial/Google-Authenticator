<?php
require 'vendor/autoload.php';
$authenticator = new PHPGangsta_GoogleAuthenticator();
$secret = "IKNV32R3IIP7FGZU"; //You can generate a secret key with $authenticator->createSecret(); function

$website = ''; //This variable is optional, you can use your website or no.
$title= 'Adryan'; //You can use $_SESSION username to get username!
$qrCodeUrl = $authenticator->getQRCodeGoogleUrl($title, $secret, $website); //With this variable you will generate QR code!
echo "<img src='$qrCodeUrl'>"; // You echo code qr to scan in Google Authenticator Application

$otp = "197502"; // In this variable you will put the code generated in Google Authenticator Application

$tolerance = 0;
$checkResult = $authenticator->verifyCode($secret, $otp, $tolerance);    

if ($checkResult) 
{
    echo 'OTP is Validated Succesfully';

} else {
    echo 'FAILED';
}

?>